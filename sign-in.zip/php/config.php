<?php

$connection = new mysqli("127.0.0.1", "root", "", "cyber_valley");