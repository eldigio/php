<?php
require_once "php/config.php";
require_once "utils.php";

$sql = "SELECT * FROM studenti";
$result = $connection->query($sql);

while($row = $result->fetch_assoc()) {
  echo "<tr>";
  if($row["id"] == $_GET["id"]) {
    echo '<form action="updateStudente.php" method="post">';
    echo '<td><input type="text" class="form-control" name="nome" value="'.$row['nome'].'"></td>';
    echo '<td><input type="text" class="form-control" name="cognome" value="'.$row['cognome'].'"></td>';
    echo '<td><input type="email" class="form-control" name="email" value="'.$row['email'].'"></td>';
    echo '<td><input type="text" class="form-control" name="password" value="'.$row['password'].'"></td>';
    echo '<td><input type="text" class="form-control" name="telefono" value="'.$row['telefono'].'"></td>';
    echo '<td><input type="text" class="form-control" name="codice_fiscale" value="'.$row['codice_fiscale'].'"></td>';
    echo '<td><input type="text" class="form-control" name="data_nascita" value="'.$row['data_nascita'].'"></td>';
    echo '<td>'.$row['data_registrazione'].'</td>';
    echo '<td><button type="submit" class="btn btn-primary">Save</button></td>';
    echo '<td><a class="btn btn-secondary" href="/" role="button">' . $icon_back . '</a></td>';
    echo '<input type="hidden" name="id" value="'.$row['id'].'">';
    echo '</form>';
    } else {
      echo "<td>" . $row["nome"] . "</td>";
      echo "<td>" . $row["cognome"] . "</td>";
      echo "<td>" . $row["email"] . "</td>";
      echo "<td>" . $row["password"] . "</td>";
      echo "<td>" . $row["telefono"] . "</td>";
      echo "<td>" . $row["codice_fiscale"] . "</td>";
      echo "<td>" . $row["data_nascita"] . "</td>";
      echo "<td>" . $row["data_registrazione"] . "</td>";
      echo '<td><a class="btn btn-warning" href="index.php?id=' . $row['id'] . '" role="button">' . $icon_edit . '</a></td>';
      echo '<td><a class="btn btn-danger" href="deleteStudente.php?id=' . $row['id'] . '" role="button">' . $icon_delete . '</a></td>';
    }
  echo "</tr>";
}
$connection->close();